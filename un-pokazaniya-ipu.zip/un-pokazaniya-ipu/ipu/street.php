<option value="Вольный">Вольный</option>
<option value="Кирова">Кирова</option>
<option value="Чехова">Чехова</option>
